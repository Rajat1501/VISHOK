package com.example.vision_ai

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
