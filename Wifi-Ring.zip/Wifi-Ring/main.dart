import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(const VisionAIApp());
}

class VisionAIApp extends StatelessWidget {
  const VisionAIApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(debugShowCheckedModeBanner: false, home: ModeScreen());
  }
}

class ModeScreen extends StatelessWidget {
  ModeScreen({super.key});

  // 🔴 CHANGE THIS TO YOUR RASPBERRY PI IP
  final String piUrl = "http://10.228.67.60:8001/mode";

  Future<void> sendMode(String mode) async {
    try {
      final response = await http.post(
        Uri.parse(piUrl),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"mode": mode}),
      );

      debugPrint("✅ Sent mode: $mode | Status: ${response.statusCode}");
    } catch (e) {
      debugPrint("❌ Error sending mode: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Vision AI Controller"),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: GridView.count(
          crossAxisCount: 2,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          children: [
            modeButton("Object Detection", "object_detection"),
            modeButton("Text Read", "text_read"),
            modeButton("Summarize View", "scene_summary"),
            modeButton("Currency Value / Sum", "currency_detection"),
            modeButton("Multilingual Support", "multilingual"),
            modeButton("Face Recognition", "face_recognition"),
          ],
        ),
      ),
    );
  }

  Widget modeButton(String title, String mode) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(padding: const EdgeInsets.all(16)),
      onPressed: () => sendMode(mode),
      child: Text(
        title,
        textAlign: TextAlign.center,
        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
      ),
    );
  }
}
